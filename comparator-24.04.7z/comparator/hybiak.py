import random

import numpy as np
from player import Player


class Hybiak(Player):

    def __init__(self, name):
        super().__init__(name)
        self.already_played_cards = set()

    def putCard(self, declared_card):

        if len(self.cards) == 1 and declared_card is not None and self.cards[0][0] < declared_card[0]:
            return "draw"

        if declared_card is not None:
            self.already_played_cards.add(declared_card)

        self.cards.sort(key=lambda card: card[0])

        if declared_card is None or declared_card[0] <= self.cards[0][0]:
            return self.cards[0], self.cards[0]
        else:
            if declared_card[0] < self.cards[0][0]:
                fake_card = (declared_card[0], self.cards[0][1])
            if np.mean([card[0] for card in self.cards]) < declared_card[0]:
                fake_card = (declared_card[0], self.cards[0][1])
                
                return self.cards[0], fake_card
            return "draw"

    def checkCard(self, opponent_declaration):
        if opponent_declaration is None:
            return False

        if opponent_declaration in self.already_played_cards:
            return True

        if opponent_declaration in self.cards:
            return True

        all_accessible_cards = self.cards + list(self.already_played_cards)
        cards_with_same_rank = [card for card in all_accessible_cards if card[0] == opponent_declaration[0]]

        l = len(cards_with_same_rank)
        if l == 4:
            return True

        return False
